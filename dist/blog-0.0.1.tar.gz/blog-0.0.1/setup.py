from distutils.core import setup
import glob


#print(glob.glob('templates/*.html'))

setup(
    name="blog",
    version="0.0.1",
    author="wang",
    author_email="604603701@qq.com",
    description="diango react bolg",
    packages=['blog','user','post'],
    data_files=glob.glob('templates/*.html')+['requirement','manage.py'],
)




